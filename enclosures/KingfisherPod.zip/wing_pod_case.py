#!/usr/bin/env python3
# =============================================================================
#  WING-MOUNTED AIR-DATA POD enclosure  (printed insert that lives inside a
#  foam + fiberglass aerodynamic pod)
#
#  Boards: SparkFun Pro Micro ESP32-C3, Battery Babysitter, Micro Magnetometer
#          MMC5983MA, BMP581 (static), Qwiic 5V Boost (-> Holybro MS4525DO),
#          850/1000 mAh LiPo.
#
#  Air data:  PITOT port -> MS4525DO high   |   STATIC port -> static bay
#             (BMP581 inside) -> stub -> MS4525DO low.
#
#  Parametric -> exports STEP (editable in Fusion) + STL (print-ready)
#  Printer : AnkerMake M5C  (220 x 220 x 250)  -  PETG
#  Fasteners: M2.5 brass heat-set inserts + M2.5 screws (lid)
#
#  >>> EVERYTHING you may want to tune lives in the PARAMETERS block. <<<
#  Dimensions flagged (VERIFY) are best-guess until measured with calipers.
#  Re-run:  python3 wing_pod_case.py
# =============================================================================
import cadquery as cq

mm = 1.0

# -----------------------------------------------------------------------------
# SHELL
# -----------------------------------------------------------------------------
WALL        = 2.5      # side wall thickness
FLOOR_T     = 2.5      # floor thickness
LID_T       = 2.5      # lid plate thickness
INT_W       = 42.0     # interior width  (Y)  - driven by 34 mm battery + margin
INT_H       = 16.0     # interior height (Z)  - floor-top to wall-top
LID_LIP_H   = 4.0      # lid alignment lip depth
LID_LIP_GAP = 0.40     # clearance so lid lip drops in (tune per printer)
EDGE_FILLET = 1.5      # outer vertical edge softening

# board standoff (pad) height - boards rest here, lid clamps them
STANDOFF    = 3.0
PCB_T       = 1.6      # nominal PCB thickness (for cutout heights)

# -----------------------------------------------------------------------------
# FASTENERS  -  ALL M2.5  (smallest robust common machine screw)
#   LID  : M2.5 screw -> brass heat-set insert in each corner boss
#          (inserts survive repeated opening for battery swaps)
#   BOARDS: M2.5 self-tapping screw straight into a printed post
#          (set-and-forget, lets the posts stay compact)
# -----------------------------------------------------------------------------
INS_HOLE_D   = 3.4     # M2.5 heat-set insert pilot hole (VERIFY vs your inserts)
INS_DEPTH    = 5.5     # insert hole depth
LID_SCREW_D  = 2.8     # M2.5 clearance hole in lid
LID_CB_D     = 5.0     # lid counterbore diameter (M2.5 head)
LID_CB_DEPTH = 2.2
BOSS_R       = 3.4     # corner boss radius (~1.7 mm wall around the insert)

# board-mount screw posts (used where mounting holes are MEASURED)
POST_OD      = 4.6     # screw-post outer diameter (~1.2 mm wall around pilot)
SCREW_PILOT  = 2.1     # M2.5 self-tap pilot bore (PETG); open to 2.5 if heat-setting

# -----------------------------------------------------------------------------
# PNEUMATIC PORTS  (front wall, facing the pitot/nose direction)
#   Socket-style: your 2.5 mm-OD line PUSHES INTO the bore, sealed with a dab
#   of silicone.  (A printed barb thin enough for 2.5 mm tube to slip OVER is
#   too fragile on FDM, so we socket instead.)
# -----------------------------------------------------------------------------
TUBE_OD      = 2.5     # MEASURED: outside dia of your pitot/static line
TUBE_BORE    = 2.7     # socket bore = slip fit for the 2.5 mm tube (tune fit)
STUB_OD      = 5.0     # outside diameter of the port sleeve
STUB_LEN     = 6.0     # how far the sleeve sticks out past the wall

# -----------------------------------------------------------------------------
# STATIC BAY (sealed compartment around the BMP581)
#   3 printed walls + the case +Y wall.  Wall tops carry a gasket groove for a
#   1.5 mm silicone O-cord; cable notches sealed with RTV.
#   BMP581 is a daisy-chain PASS-THROUGH: BOTH Qwiic connectors live, on the
#   +/-X edges.  +X faces the rear cluster (Boost), -X faces the magnetometer at
#   the nose.  Each connector gets clearance + its own sealed notch.  A nose
#   channel in front of the bay lets the -X cable turn toward the mag.
#   Mounting-hole edge faces -Y.  BAY_X1 derived from the board + clearances.
# -----------------------------------------------------------------------------
BAY_WALL      = 3.0    # thick enough to hold a gasket groove
BAY_X0        = 6.0    # nose channel (front wall -> bay) for the -X cable to turn
BAY_Y0        = 13.0   # bay occupies the +Y side of the nose
BAY_Y1        = INT_W  # to the +Y case wall (shares that wall)
GASKET_W      = 1.6    # gasket groove width (for ~1.5 mm silicone cord)
GASKET_D      = 1.0    # gasket groove depth
BMP_CONN_FREE = 6.0    # gap at the -X (live, nose-side) connector -> mated plug
BMP_CONN_USED = 8.0    # gap at the +X (live, rear-side) connector -> mated plug
BMP_FEED_Y    = 20.0   # static feed bridge enters the bay here (clear of the notches)

# =============================================================================
# BOARD PLACEMENTS    (interior coords: x = 0 front/nose .. INT_L rear,
#                      y = 0 .. INT_W,  z measured from floor top)
# each: name, x0, y0, x_len, y_len, mount-hole list [(hx,hy),...] (board-local)
# Hole coords are best-guess (VERIFY).  Empty list -> captured by walls + lid.
# =============================================================================
BMP581_L, BMP581_W = 25.4, 25.4          # SEN-20170 standard 1x1
BOOST_L,  BOOST_W  = 24.5, 24.5          # AP3012K 1x1
PM_L,     PM_W     = 17.8, 33.0          # Pro Micro ESP32-C3 (long axis along Y)
MAG_L,    MAG_W    = 19.0, 7.6           # MMC5983MA Qwiic Micro
MS_L,     MS_W     = 22.9, 17.0          # MS4525DO carrier  MEASURED (long axis = X)
BABY_L,   BABY_W   = 33.0, 33.0          # Battery Babysitter  MEASURED 33x33
BATT_L,   BATT_W   = 43.0, 34.0          # 850 mAh (VERIFY/ swap to 1000 mAh)
BATT_H             = 6.2
# MS4525DO barbs: off the -X short end, 4.3 mm center-spacing, OD 3.5 (tip 2.1);
#                 JST connector off the +X short end.
MS_BARB_DY    = 4.3
MS_HOLE_INSET = 2.54    # 0.1" corner inset of the two diagonal M2.5 holes
MS_HOLE_FLIP  = False    # holes at -X+Y & +X-Y corners

# running layout along X (front -> rear).  Gaps leave room for the MS4525
# barbs (-X) and JST (+X), and for tube routing.  (Length runs on the long axis;
# the finished part prints diagonally on the 220x220 bed.)
# --- static bay sized around the rotated BMP581 + its connector clearances ---
BMP_X0   = BAY_X0 + BAY_WALL + BMP_CONN_FREE          # board nose-side gap
BAY_X1   = BMP_X0 + BMP581_L + BMP_CONN_USED + BAY_WALL
BMP_Y0   = BAY_Y0 + BAY_WALL + (BAY_Y1-(BAY_Y0+BAY_WALL)-BMP581_W)/2  # centred in bay Y
MAG_X0   = 6.0                           # nose side-channel, away from power
MS_X0    = BAY_X1 + 4.0                   # just aft of bay; barbs face the bay/nose
MS_Y0    = 14.0                          # barbs land near the static stub / pitot channel
BOOST_X0 = MS_X0 + MS_L + 6.0             # after MS4525 + JST clearance
PM_X0    = BOOST_X0 + BOOST_L + 3.0
PM_Y0    = 2.0                           # near -Y wall so USB-C reaches ~flush
BATT_X0  = PM_X0 + PM_L + 3.0
BABY_X0  = BATT_X0 + BATT_L + 3.5
INT_L    = BABY_X0 + BABY_L + 3.0         # rear margin -> interior length

# board records  (mount holes given board-local from its x0,y0 corner)
#   holes=[] -> board captured by standoff pads + corner nubs (+ lid/foam).
#   holes=[...] (MEASURED) -> real M2.5 self-tap posts.
INSET = 2.54   # 0.1" hole inset used by the SparkFun Qwiic boards
# MS4525 diagonal pair (board-local).  FLIP False -> -X+Y & +X-Y;
#                                      FLIP True  -> -X-Y (barb end) & +X+Y (JST end).
_MSH = [(MS_HOLE_INSET, MS_W-MS_HOLE_INSET), (MS_L-MS_HOLE_INSET, MS_HOLE_INSET)]
if MS_HOLE_FLIP:
    _MSH = [(MS_HOLE_INSET, MS_HOLE_INSET), (MS_L-MS_HOLE_INSET, MS_W-MS_HOLE_INSET)]
BOARDS = {
    # BMP581 rotated: Qwiic connectors on +/-X edges; two mount holes on the -Y
    # edge (0.1" in from each side); +X connector points at the cable notch.
    "BMP581":  dict(x0=BMP_X0,  y0=BMP_Y0, xl=BMP581_L, yl=BMP581_W,
                    holes=[(INSET, INSET), (BMP581_L-INSET, INSET)]),
    # MAG: single hole at the end OPPOSITE the Qwiic (Qwiic faces +X / inward)
    "MAG":     dict(x0=MAG_X0,  y0=2.5,  xl=MAG_L, yl=MAG_W,
                    holes=[(INSET, MAG_W/2)]),
    # MS4525DO carrier: long axis along X, barbs out -X (toward bay/nose), JST +X;
    #                   two M2.5 holes on the diagonal (see MS_HOLE_FLIP)
    "MS4525":  dict(x0=MS_X0,   y0=MS_Y0, xl=MS_L, yl=MS_W, holes=_MSH),
    # 5V boost: holes at all four corners, 0.1" in from each side
    "BOOST":   dict(x0=BOOST_X0,y0=(INT_W-BOOST_W)/2, xl=BOOST_L, yl=BOOST_W,
                    holes=[(INSET,INSET),(BOOST_L-INSET,INSET),
                           (INSET,BOOST_W-INSET),(BOOST_L-INSET,BOOST_W-INSET)]),
    "PROMICRO":dict(x0=PM_X0,   y0=PM_Y0, xl=PM_L, yl=PM_W, holes=[]),  # castellated, no holes
    "BABY":    dict(x0=BABY_X0, y0=(INT_W-BABY_W)/2, xl=BABY_L, yl=BABY_W,
                    holes=[(2.5,2.5),(BABY_L-2.5,2.5),
                           (2.5,BABY_W-2.5),(BABY_L-2.5,BABY_W-2.5)]),  # MEASURED corners
}

# battery bay
BATT_Y0  = (INT_W - BATT_W)/2

# USB cutouts (VERIFY positions/size against your boards)
USBC_W, USBC_H   = 12.0, 7.0     # Pro Micro USB-C, on the -Y side wall
MICROUSB_W, MUSB_H = 9.0, 5.0    # Babysitter micro-USB, on the +X rear wall

# Lid press-pads: bosses on the lid underside that hold clamp-only boards down
# through a soft foam pad (foam clears any tall components; face sits high).
PRESS_FACE_Z = 11.0   # world z of the pad face (above ~3 mm components; foam fills gap)
PRESS_PAD_WL = (7.0, 7.0)
# (x, y) interior centres of each pad -> over the Pro Micro near its two short ends
PRESS_PADS = [(PM_X0 + PM_L/2, PM_Y0 + 6.0),
              (PM_X0 + PM_L/2, PM_Y0 + PM_W - 6.0)]

OUT_L = INT_L + 2*WALL
OUT_W = INT_W + 2*WALL
WALL_TOP = FLOOR_T + INT_H       # z of wall top
print(f"OUTER  L x W x H = {OUT_L:.1f} x {OUT_W:.1f} x {WALL_TOP+LID_T:.1f} mm")

# helper: interior (x,y) -> world. World origin at outer min corner.
def IX(x): return WALL + x
def IY(y): return WALL + y

# =============================================================================
# BASE
# =============================================================================
def build_base():
    # solid outer block, then hollow the top to leave floor + 4 walls
    base = (cq.Workplane("XY")
            .box(OUT_L, OUT_W, WALL_TOP, centered=(False, False, False)))
    # soften outer vertical edges
    base = base.edges("|Z").fillet(EDGE_FILLET)
    # interior pocket (open top)
    pocket = (cq.Workplane("XY")
              .transformed(offset=(WALL, WALL, FLOOR_T))
              .box(INT_L, INT_W, INT_H+1, centered=(False, False, False)))
    base = base.cut(pocket)

    # ---- corner bosses with insert holes (lid screws) ----
    boss_inset = BOSS_R + 0.5
    corners = [(boss_inset, boss_inset),
               (INT_L-boss_inset, boss_inset),
               (boss_inset, INT_W-boss_inset),
               (INT_L-boss_inset, INT_W-boss_inset)]
    for (cx, cy) in corners:
        boss = (cq.Workplane("XY")
                .transformed(offset=(IX(cx), IY(cy), FLOOR_T))
                .circle(BOSS_R).extrude(INT_H))
        base = base.union(boss)
        hole = (cq.Workplane("XY")
                .transformed(offset=(IX(cx), IY(cy), WALL_TOP - INS_DEPTH))
                .circle(INS_HOLE_D/2).extrude(INS_DEPTH+0.1))
        base = base.cut(hole)

    # ---- board mounting: screw posts where holes are MEASURED, else pads ----
    for name, b in BOARDS.items():
        if b["holes"]:
            # real screw posts (board screws down onto these)
            for (hx, hy) in b["holes"]:
                post = (cq.Workplane("XY")
                        .transformed(offset=(IX(b["x0"]+hx), IY(b["y0"]+hy), FLOOR_T))
                        .circle(POST_OD/2).extrude(STANDOFF))
                base = base.union(post)
                pilot = (cq.Workplane("XY")
                         .transformed(offset=(IX(b["x0"]+hx), IY(b["y0"]+hy), FLOOR_T))
                         .circle(SCREW_PILOT/2).extrude(STANDOFF+0.1))
                base = base.cut(pilot)
        else:
            # standoff pads (board clamped by lid)
            pad_pts = [(b["x0"]+3, b["y0"]+3),
                       (b["x0"]+b["xl"]-3, b["y0"]+3),
                       (b["x0"]+3, b["y0"]+b["yl"]-3),
                       (b["x0"]+b["xl"]-3, b["y0"]+b["yl"]-3)]
            for (px, py) in pad_pts:
                pad = (cq.Workplane("XY")
                       .transformed(offset=(IX(px), IY(py), FLOOR_T))
                       .circle(2.2).extrude(STANDOFF))
                base = base.union(pad)
        # locating nubs at board corners (XY capture, anti-rotation) - all boards
        for (nx, ny, dx, dy) in [
            (b["x0"]-1.0, b["y0"]-1.0, -1, -1),
            (b["x0"]+b["xl"]+1.0, b["y0"]-1.0, 1, -1),
            (b["x0"]-1.0, b["y0"]+b["yl"]+1.0, -1, 1),
            (b["x0"]+b["xl"]+1.0, b["y0"]+b["yl"]+1.0, 1, 1)]:
            if 0 < nx < INT_L and 0 < ny < INT_W:
                nub = (cq.Workplane("XY")
                       .transformed(offset=(IX(nx), IY(ny), FLOOR_T))
                       .circle(1.4).extrude(STANDOFF+PCB_T+0.6))
                base = base.union(nub)

    # ---- STATIC BAY walls (open-top compartment; lid seals it) ----
    bay_outer = (cq.Workplane("XY")
                 .transformed(offset=(IX(BAY_X0), IY(BAY_Y0), FLOOR_T))
                 .box(BAY_X1-BAY_X0, BAY_Y1-BAY_Y0, INT_H, centered=(False, False, False)))
    bay_inner = (cq.Workplane("XY")
                 .transformed(offset=(IX(BAY_X0)+BAY_WALL, IY(BAY_Y0)+BAY_WALL, FLOOR_T))
                 .box(BAY_X1-BAY_X0-2*BAY_WALL, BAY_Y1-BAY_Y0-BAY_WALL, INT_H+1,
                      centered=(False, False, False)))
    bay = bay_outer.cut(bay_inner)
    base = base.union(bay)
    # two Qwiic cable notches (user seals each with silicone): +X wall -> rear
    # cluster, -X wall -> magnetometer.  Both at the connector centre-line.
    conn_y = BMP_Y0 + BMP581_W/2
    notch_pX = (cq.Workplane("XY")
                .transformed(offset=(IX(BAY_X1)-BAY_WALL-0.5, IY(conn_y), WALL_TOP-3.5))
                .box(BAY_WALL+2, 5.0, 3.5, centered=(False, True, False)))
    base = base.cut(notch_pX)
    notch_nX = (cq.Workplane("XY")
                .transformed(offset=(IX(BAY_X0)-1.0, IY(conn_y), WALL_TOP-3.5))
                .box(BAY_WALL+2, 5.0, 3.5, centered=(False, True, False)))
    base = base.cut(notch_nX)
    # gasket groove on the 3 printed bay-wall tops (for ~1.5 mm silicone O-cord).
    # +Y side is the case wall -> sealed by the main lid lip; dab RTV in its 2 corners.
    g_z = WALL_TOP - GASKET_D
    gx_len = BAY_X1 - BAY_X0
    gy_len = BAY_Y1 - BAY_Y0
    for (gx, gy, w, l) in [
        (BAY_X0 + BAY_WALL/2, BAY_Y0, GASKET_W, gy_len),          # -X wall
        (BAY_X1 - BAY_WALL/2, BAY_Y0, GASKET_W, gy_len),          # +X wall
    ]:
        groove = (cq.Workplane("XY")
                  .transformed(offset=(IX(gx), IY(gy), g_z))
                  .box(w, l, GASKET_D+0.1, centered=(True, False, False)))
        base = base.cut(groove)
    groove = (cq.Workplane("XY")                                  # -Y wall
              .transformed(offset=(IX(BAY_X0), IY(BAY_Y0 + BAY_WALL/2), g_z))
              .box(gx_len, GASKET_W, GASKET_D+0.1, centered=(False, True, False)))
    base = base.cut(groove)

    # ---- pneumatic port stubs (cylinders along +X, built then translated) ----
    def x_cyl(r, length, xw, yw, zw):
        # cylinder along +X starting at world x=xw
        return (cq.Workplane("YZ").circle(r).extrude(length)
                .translate((xw, yw, zw)))

    port_z = FLOOR_T + 6.0
    # STATIC: solid tube bridges from the front face THROUGH the open cavity
    # into the static bay interior, so static air is isolated to the bay.
    feed_yw = IY(BMP_FEED_Y)
    static_solid = STUB_LEN + WALL + BAY_X0 + BAY_WALL
    base = base.union(x_cyl(STUB_OD/2, static_solid, -STUB_LEN, feed_yw, port_z))
    base = base.cut(x_cyl(TUBE_BORE/2, static_solid + 4, -STUB_LEN-1, feed_yw, port_z))
    # PITOT: stub out the front (-X), bore opens into the open interior side-channel
    pitot_yw = IY(6.0)
    base = base.union(x_cyl(STUB_OD/2, STUB_LEN + WALL + 1, -STUB_LEN, pitot_yw, port_z))
    base = base.cut(x_cyl(TUBE_BORE/2, STUB_LEN + WALL + 3, -STUB_LEN-1, pitot_yw, port_z))

    # static reference stub out the bay +X wall, aimed at the MS4525 upper barb;
    # stops short of the board.  (user jumpers it to the LOW barb; pitot -> HIGH barb)
    barb_hi_y = MS_Y0 + MS_W/2 + MS_BARB_DY/2
    stub_yw = IY(barb_hi_y)
    sx = IX(BAY_X1) - BAY_WALL
    base = base.union(x_cyl(STUB_OD/2, BAY_WALL + 3, sx, stub_yw, port_z))
    base = base.cut(x_cyl(TUBE_BORE/2, BAY_WALL + 5, sx - 1, stub_yw, port_z))

    # ---- BATTERY BAY walls + finger scoop + JST notch -------------------
    bb_x0, bb_x1 = BATT_X0-1.5, BATT_X0+BATT_L+1.5
    bb_y0, bb_y1 = BATT_Y0-1.5, BATT_Y0+BATT_W+1.5
    ring_out = (cq.Workplane("XY")
                .transformed(offset=(IX(bb_x0), IY(bb_y0), FLOOR_T))
                .box(bb_x1-bb_x0, bb_y1-bb_y0, BATT_H+1.5, centered=(False, False, False)))
    ring_in = (cq.Workplane("XY")
               .transformed(offset=(IX(bb_x0)+2.0, IY(bb_y0)+2.0, FLOOR_T))
               .box(bb_x1-bb_x0-4.0, bb_y1-bb_y0-4.0, BATT_H+3, centered=(False, False, False)))
    batt_ring = ring_out.cut(ring_in)
    # finger scoop in the front wall of the battery bay (to lift battery)
    scoop = (cq.Workplane("XY")
             .transformed(offset=(IX(bb_x0)+(bb_x1-bb_x0)/2, IY(bb_y0)+1.0, FLOOR_T))
             .box(16, 6, BATT_H+4, centered=(True, False, False)))
    batt_ring = batt_ring.cut(scoop)
    base = base.union(batt_ring)

    # ---- USB cutouts ----------------------------------------------------
    # Pro Micro USB-C: centered on the board's short (17.8 mm) side -> exits the
    # -Y side wall, centered on the board's X (MEASURED: mid of a short side)
    pm = BOARDS["PROMICRO"]
    usbc_x = pm["x0"] + pm["xl"]/2
    usbc_z = FLOOR_T + STANDOFF + PCB_T
    cut = (cq.Workplane("XY")
           .transformed(offset=(IX(usbc_x), WALL/2, usbc_z))
           .box(USBC_W, WALL+2, USBC_H, centered=(True, True, True)))
    base = base.cut(cut)
    # Babysitter micro-USB on +X rear wall, 10 mm from the -Y end (MEASURED)
    bb = BOARDS["BABY"]
    musb_y = bb["y0"] + 10.0
    musb_z = FLOOR_T + STANDOFF + PCB_T
    cut = (cq.Workplane("XY")
           .transformed(offset=(OUT_L-WALL/2, IY(musb_y), musb_z))
           .box(WALL+2, MICROUSB_W, MUSB_H, centered=(True, True, True)))
    base = base.cut(cut)

    return base

# =============================================================================
# LID
# =============================================================================
def build_lid():
    lid = (cq.Workplane("XY")
           .box(OUT_L, OUT_W, LID_T, centered=(False, False, False)))
    lid = lid.edges("|Z").fillet(EDGE_FILLET)
    # alignment lip (drops inside the walls)
    lip = (cq.Workplane("XY")
           .transformed(offset=(WALL+LID_LIP_GAP, WALL+LID_LIP_GAP, -LID_LIP_H))
           .box(INT_L-2*LID_LIP_GAP, INT_W-2*LID_LIP_GAP, LID_LIP_H,
                centered=(False, False, False)))
    lid = lid.union(lip)
    # carve clearance for the 4 corner bosses out of the lip
    boss_inset = BOSS_R + 0.5
    corners = [(boss_inset, boss_inset),
               (INT_L-boss_inset, boss_inset),
               (boss_inset, INT_W-boss_inset),
               (INT_L-boss_inset, INT_W-boss_inset)]
    for (cx, cy) in corners:
        clr = (cq.Workplane("XY")
               .transformed(offset=(IX(cx), IY(cy), -LID_LIP_H))
               .circle(BOSS_R+0.4).extrude(LID_LIP_H+0.1))
        lid = lid.cut(clr)
        # screw hole + counterbore from the top
        sh = (cq.Workplane("XY")
              .transformed(offset=(IX(cx), IY(cy), -LID_LIP_H-0.1))
              .circle(LID_SCREW_D/2).extrude(LID_T+LID_LIP_H+0.2))
        lid = lid.cut(sh)
        cb = (cq.Workplane("XY")
              .transformed(offset=(IX(cx), IY(cy), LID_T-LID_CB_DEPTH))
              .circle(LID_CB_D/2).extrude(LID_CB_DEPTH+0.1))
        lid = lid.cut(cb)
    # carve lip clearance over the static-bay walls so the lid seats on them
    bayclr = (cq.Workplane("XY")
              .transformed(offset=(IX(BAY_X0)-0.3, IY(BAY_Y0)-0.3, -LID_LIP_H))
              .box(BAY_X1-BAY_X0+0.6, BAY_Y1-BAY_Y0+0.6, LID_LIP_H+0.1,
                   centered=(False, False, False)))
    lid = lid.cut(bayclr)
    # carve lip clearance over the battery-bay walls
    bb_x0, bb_x1 = BATT_X0-1.5, BATT_X0+BATT_L+1.5
    bb_y0, bb_y1 = BATT_Y0-1.5, BATT_Y0+BATT_W+1.5
    battclr = (cq.Workplane("XY")
               .transformed(offset=(IX(bb_x0)-0.3, IY(bb_y0)-0.3, -LID_LIP_H))
               .box(bb_x1-bb_x0+0.6, bb_y1-bb_y0+0.6, LID_LIP_H+0.1,
                    centered=(False, False, False)))
    lid = lid.cut(battclr)
    # press-pads: bosses on the lid underside that hold clamp-only boards down
    # (the Pro Micro) through a soft foam pad.  Face sits at PRESS_FACE_Z.
    pad_h = WALL_TOP - PRESS_FACE_Z
    pw, pl = PRESS_PAD_WL
    for (px, py) in PRESS_PADS:
        pad = (cq.Workplane("XY")
               .transformed(offset=(IX(px), IY(py), -pad_h))
               .box(pw, pl, pad_h, centered=(True, True, False)))
        lid = lid.union(pad)
    return lid

# =============================================================================
if __name__ == "__main__":
    base = build_base()
    lid  = build_lid()
    cq.exporters.export(base, "case_base.step")
    cq.exporters.export(base, "case_base.stl")
    cq.exporters.export(lid,  "case_lid.step")
    cq.exporters.export(lid,  "case_lid.stl")
    # also a combined assembly STEP (lid floated above)
    asm = base.union(lid.translate((0, 0, WALL_TOP + 14)))
    cq.exporters.export(asm, "case_assembly.step")
    print("exported base/lid STEP + STL")
