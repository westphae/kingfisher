#!/usr/bin/env python3
# =============================================================================
#  Raspberry Pi 5 aviation enclosure  (Stratux-style: Pi + GPS + IMU)
#  Parametric model -> exports STEP (editable in Fusion) + STL (print-ready)
#
#  Target printer : AnkerMake M5C (220x220x250 build vol) - PETG
#  Fasteners      : M2.5 brass heat-set inserts + M2.5 screws throughout
#
#  >>> EVERYTHING you might tune lives in the PARAMETERS block below. <<<
#  Re-run after editing:  python3 pi5_aviation_case.py
# =============================================================================
import cadquery as cq

# ----------------------------------------------------------------------------- 
# PARAMETERS  (all millimetres)
# ----------------------------------------------------------------------------- 
# --- shell ---
WALL        = 3.0       # wall & floor thickness
CLR         = 7.0       # clearance Pi/boards -> walls (also = airflow gap)
BACK_CLR    = 9.0       # extra clearance behind GPS so rear lid posts clear it
WALL_H      = 34.0      # interior wall height (floor top -> wall top)
LID_T       = 3.0       # lid plate thickness
LID_LIP_H   = 4.0       # depth of lid alignment lip that nests inside walls
LID_LIP_GAP = 0.4       # clearance so the lid lip drops in (tune per printer)

# --- M2.5 heat-set inserts  (VERIFY against YOUR inserts!) ---
INS_HOLE_D  = 3.6       # insert pilot-hole diameter
INS_DEPTH   = 5.0       # insert hole depth
BOSS_D      = 6.0       # outside diameter of a boss that holds an insert

# --- Raspberry Pi 5 (official mechanical drawing) ---
PI_L        = 85.0      # length (X)
PI_W        = 56.0      # width  (Y)
PI_HOLE_INSET = 3.5     # holes 3.5 mm from board edges
PI_HOLE_DX  = 58.0      # hole spacing X
PI_HOLE_DY  = 49.0      # hole spacing Y
STANDOFF_H  = 10.0      # Pi raised off floor for under-board airflow
PI_PCB_T    = 1.6
USBC_X      = 11.2      # USB-C centre, from the LEFT corner of front edge
SD_W         = 16.0     # microSD access width (along the short face)
SD_CARD_GAP  = 3.0      # side slot extends this far above the standoff top
SD_FLOOR_DEPTH = 27.0   # how far the floor notch reaches in under the card
# Card protrudes only ~2 mm past the Pi edge, so access is L-shaped: a slot in
# the lower side wall PLUS a notch in the floor to reach the card from beneath.
COOLER_L    = 63.5      # Active Cooler footprint
COOLER_W    = 42.5
COOLER_H    = 14.0      # cooler height above PCB (intake is top-centre)

# --- SparkFun NEO-M9N SMA  (from your dimensioned PNG; 1.60" x 1.45") ---
GPS_L       = 40.64     # 1.60"
GPS_W       = 36.83     # 1.45"
GPS_HOLE_INSET = 2.54   # all 4 holes are 0.10" in from BOTH edges (true corners)
# (the 0.41" callout on your drawing = SMA connector centre, not a mounting hole)

# --- ICM-45686 IMU breakout (your measurements) ---
IMU_L       = 20.6
IMU_W       = 17.8
IMU_HOLE_SHORT_INSET = 2.5   # holes 2.5 mm from each short edge
IMU_HOLE_LONG_INSET  = 5.0   # holes 5.0 mm from one long edge

# --- shared board mounting ---
BOARD_PED_H = 7.0       # pedestal height for GPS/IMU (>= INS_DEPTH so insert fits)

# --- SMA bulkhead pass-through (panel-mount, short jumper to board) ---
SMA_D       = 6.5       # bulkhead hole dia (standard SMA ~6.35-6.5)
SMA_Z       = 18.0      # height of SMA hole centre on back wall
SMA_X       = 78.0      # X position on back wall: offset toward IMU side (roomier)

# --- velcro / Dual-Lock landing pad (recess on the underside) ---
PAD_L       = 70.0
PAD_W       = 60.0
PAD_DEPTH   = 1.0       # set 0.0 for a flat bottom

# --- vents ---
INTAKE_R      = 21.0    # radius of intake grille zone over the cooler
INTAKE_HOLE_D = 4.0
INTAKE_PITCH  = 6.5
SLOT_W        = 3.0     # wall exhaust slot width
SLOT_COUNT    = 6

# ----------------------------------------------------------------------------- 
# DERIVED LAYOUT  (interior origin = inside front-left corner, on floor top)
# Outer origin (0,0,0) = outer front-left-bottom corner.
# ----------------------------------------------------------------------------- 
INT_X = CLR + PI_L + CLR                 # interior X
BAY_GAP = 5.0
INT_Y = CLR + PI_W + BAY_GAP + GPS_W + BACK_CLR   # interior Y (bay sized for GPS)
OX = 2*WALL + INT_X
OY = 2*WALL + INT_Y
OZ = WALL + WALL_H                        # base outer height

def io(x, y):                             # interior -> outer (XY)
    return (WALL + x, WALL + y)

# Pi placement (Pi-local origin at interior (CLR,CLR))
PIx0, PIy0 = io(CLR, CLR)                 # Pi front-left corner (outer)
pi_holes = [(PIx0 + PI_HOLE_INSET + dx, PIy0 + PI_HOLE_INSET + dy)
            for dx in (0, PI_HOLE_DX) for dy in (0, PI_HOLE_DY)]
cooler_cx = PIx0 + PI_L/2
cooler_cy = PIy0 + PI_W/2

# Lid corner posts (interior corners, offset so they clear the Pi)
post_off = BOSS_D/2 + 0.5
lid_posts = [io(post_off, post_off), io(INT_X-post_off, post_off),
             io(post_off, INT_Y-post_off), io(INT_X-post_off, INT_Y-post_off)]

# Bay boards
GPSx0, GPSy0 = io(CLR-1, CLR + PI_W + BAY_GAP)        # GPS lower-left (outer)
gps_holes = [(GPSx0 + hx, GPSy0 + hy)
             for hx in (GPS_HOLE_INSET, GPS_L - GPS_HOLE_INSET)
             for hy in (GPS_HOLE_INSET, GPS_W - GPS_HOLE_INSET)]

IMUx0, IMUy0 = io(CLR + PI_L - IMU_L - 3, CLR + PI_W + BAY_GAP + 4)
imu_holes = [(IMUx0 + IMU_HOLE_SHORT_INSET,        IMUy0 + IMU_HOLE_LONG_INSET),
             (IMUx0 + IMU_L - IMU_HOLE_SHORT_INSET, IMUy0 + IMU_HOLE_LONG_INSET)]
imu_nubs  = [(IMUx0 + 3,         IMUy0 + IMU_W - 3),
             (IMUx0 + IMU_L - 3, IMUy0 + IMU_W - 3)]

# ----------------------------------------------------------------------------- 
# BASE
# ----------------------------------------------------------------------------- 
def boss(points, top_z, with_insert=True, d=BOSS_D):
    s = (cq.Workplane("XY").pushPoints(points).circle(d/2).extrude(top_z))
    if with_insert:
        s = (s.faces(">Z").workplane()
               .pushPoints(points).hole(INS_HOLE_D, INS_DEPTH))
    return s

def build_base():
    # hollow tray (walls + floor, open top)
    b = (cq.Workplane("XY").box(OX, OY, OZ, centered=False)
         .faces(">Z").shell(-WALL))

    # --- bosses / standoffs / pedestals ---
    b = b.union(boss(pi_holes,  WALL + STANDOFF_H))            # Pi standoffs
    b = b.union(boss(lid_posts, OZ))                           # lid corner posts
    b = b.union(boss(gps_holes, WALL + BOARD_PED_H))           # GPS pedestals
    b = b.union(boss(imu_holes, WALL + BOARD_PED_H))           # IMU screw posts
    b = b.union(boss(imu_nubs,  WALL + BOARD_PED_H,            # IMU anti-pivot nubs
                     with_insert=False, d=4.0))

    # --- USB-C power cutout (front wall, -Y) ---
    usbc_cx = PIx0 + USBC_X
    b = b.cut(cq.Workplane("XY").box(13, WALL*3, 9, centered=(True,True,False))
              .translate((usbc_cx, WALL, WALL + STANDOFF_H - 0.5)))

    # --- microSD access (card protrudes only ~2 mm): L-shaped.
    #     1) side slot in the LOWER -X wall, 2) floor notch beneath the card so a
    #        fingernail can reach it from below and slide it out the side. ---
    sd_y   = PIy0 + PI_W/2
    sd_top = WALL + STANDOFF_H + SD_CARD_GAP
    b = b.cut(cq.Workplane("XY").box(8, SD_W, sd_top, centered=(True,True,False))
              .translate((WALL, sd_y, 0)))                       # side slot (floor->card)
    b = b.cut(cq.Workplane("XY").box(SD_FLOOR_DEPTH, SD_W, WALL*3, centered=(False,True,True))
              .translate((-1, sd_y, WALL)))                      # floor notch under card

    # --- I/O window: USB-A x4 + Ethernet (right wall, +X) ---
    iow = cq.Workplane("XY").box(WALL*3, PI_W-8, 18, centered=(True,True,False))
    b = b.cut(iow.translate((OX-WALL, PIy0 + PI_W/2, WALL + STANDOFF_H)))

    # --- SMA bulkhead pass-through (back wall, +Y) ---
    sma = (cq.Workplane("XZ").workplane(offset=-(OY))
           .center(SMA_X, SMA_Z).circle(SMA_D/2).extrude(WALL*3))
    b = b.cut(sma)

    # --- exhaust slots: left wall (-X) ---
    ys = [PIy0 + (i+0.5)*(PI_W/SLOT_COUNT) for i in range(SLOT_COUNT)]
    slot = cq.Workplane("XY").box(WALL*3, SLOT_W, WALL_H-12, centered=(True,True,False))
    for y in ys:
        b = b.cut(slot.translate((0, y, WALL+5)))

    # --- velcro / Dual-Lock recess on underside ---
    if PAD_DEPTH > 0:
        pad = cq.Workplane("XY").box(PAD_L, PAD_W, PAD_DEPTH*3, centered=True)
        b = b.cut(pad.translate((OX/2+6, OY/2+6, PAD_DEPTH*1.5 - PAD_DEPTH)))
    return b

# ----------------------------------------------------------------------------- 
# LID
# ----------------------------------------------------------------------------- 
def build_lid():
    lid = cq.Workplane("XY").box(OX, OY, LID_T, centered=False).translate((0,0,OZ))
    # alignment lip (nests inside walls)
    inner = (cq.Workplane("XY")
             .box(INT_X-2*LID_LIP_GAP, INT_Y-2*LID_LIP_GAP, LID_LIP_H, centered=False)
             .translate((WALL+LID_LIP_GAP, WALL+LID_LIP_GAP, OZ-LID_LIP_H)))
    ring = (cq.Workplane("XY")
            .box(INT_X-2*LID_LIP_GAP, INT_Y-2*LID_LIP_GAP, LID_LIP_H, centered=False)
            .translate((WALL+LID_LIP_GAP, WALL+LID_LIP_GAP, OZ-LID_LIP_H)))
    shell = (cq.Workplane("XY")
             .box(INT_X-2*LID_LIP_GAP-2*WALL, INT_Y-2*LID_LIP_GAP-2*WALL, LID_LIP_H+1, centered=False)
             .translate((WALL*2+LID_LIP_GAP, WALL*2+LID_LIP_GAP, OZ-LID_LIP_H)))
    lip = ring.cut(shell)
    lid = lid.union(lip)

    # intake grille over the cooler (grid of holes inside a circle)
    pts = []
    n = int(INTAKE_R/INTAKE_PITCH)+1
    for i in range(-n, n+1):
        for j in range(-n, n+1):
            px, py = i*INTAKE_PITCH, j*INTAKE_PITCH
            if px*px+py*py <= (INTAKE_R-INTAKE_HOLE_D/2)**2:
                pts.append((cooler_cx+px, cooler_cy+py))
    grille = (cq.Workplane("XY").pushPoints(pts)
              .circle(INTAKE_HOLE_D/2).extrude(LID_T+1).translate((0,0,OZ-0.5)))
    lid = lid.cut(grille)

    # lid screw holes (clearance + counterbore from top)
    lid = lid.cut(cq.Workplane("XY").pushPoints(lid_posts)
                  .circle(1.4).extrude(LID_T+1).translate((0,0,OZ-0.5)))
    lid = lid.cut(cq.Workplane("XY").pushPoints(lid_posts)
                  .circle(2.5).extrude(2.0).translate((0,0,OZ+LID_T-2.0)))

    # rear exhaust slots in the lid (over the bay)
    for i in range(5):
        sx = OX/2 + (i-2)*9
        lid = lid.cut(cq.Workplane("XY").box(3, 22, LID_T+1, centered=True)
                      .translate((sx, GPSy0+GPS_W/2, OZ+LID_T/2)))
    return lid

# ----------------------------------------------------------------------------- 
# BUILD + EXPORT
# ----------------------------------------------------------------------------- 
if __name__ == "__main__":
    base = build_base()
    lid  = build_lid()

    cq.exporters.export(base, "case_base.step")
    cq.exporters.export(base, "case_base.stl",  tolerance=0.05)
    cq.exporters.export(lid,  "case_lid.step")
    cq.exporters.export(lid,  "case_lid.stl",   tolerance=0.05)

    asm = cq.Assembly()
    asm.add(base, name="base", color=cq.Color(0.30,0.45,0.65))
    asm.add(lid,  name="lid",  color=cq.Color(0.75,0.78,0.82))
    asm.save("case_assembly.step")

    print(f"Outer footprint : {OX:.1f} x {OY:.1f} x {OZ+LID_T:.1f} mm")
    print(f"GPS holes (outer): {[(round(x,1),round(y,1)) for x,y in gps_holes]}")
    print("Exported: case_base/lid .step/.stl + case_assembly.step")
