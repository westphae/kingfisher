#!/usr/bin/env python3
# =============================================================================
#  Raspberry Pi 5 aviation enclosure  (Stratux-style: Pi + GPS + IMU)
#  Parametric model -> STEP (editable in Fusion) + STL (print-ready)
#  Printer: AnkerMake M5C / PETG.  Fasteners: M2.5 heat-set inserts + screws.
#
#  v2 changes from first print feedback:
#   - tighter clearances below & around (cooling proven to be fine)
#   - USB-A/Ethernet sit ~flush: I/O wall pulled in, window widened
#   - velcro pad removed (flat solid bottom for Dual-Lock)
#   - microSD floor notch shortened ~half
#   - lid lip split into segments with corner breaks (cleared the screw posts)
#   - lid exported upside-down (prints with no lip support)
# =============================================================================
import cadquery as cq

# ----------------------------------------------------------------------------- PARAMETERS (mm)
WALL        = 3.0
WALL_H      = 28.0      # interior wall height (floor top -> wall top); +2 over the
                        # minimum to give the SMA coax room to loop over the cooler
LID_T       = 4.0       # was 3.0; raised so the 2.30 mm socket-cap head fully
                        # recesses in the counterbore with solid plastic beneath
LID_LIP_H   = 3.0       # how far the lid lip drops into the case
LID_LIP_GAP = 0.4       # lip-to-wall clearance (tune per printer)
LIP_T       = 1.6       # lip rib thickness
LIP_CORNER_GAP = 7.0    # lip stops this far from each corner (clears posts)
SCREW_HEAD_H = 2.30     # YOUR lid bolts: M2.5 socket cap head thickness
SCREW_HEAD_D = 4.5      # M2.5 socket cap head OD (counterbore is cut a touch wider)

# clearances: minimal all round. With the lid posts floated (see lid_boss), the
# board slides UNDER the front posts, so CLR_F is no longer set by them. The
# new front limit is the tall Ethernet/USB stack ~1 mm from the front-right
# corner, which the post must clear: CLR_F ~= IO_FRONT_CONN_S(1) + BOSS_D/2(3)
# - POST_OFF(1) + 0.5 = 3.5. (The USB-C/left side could go tighter, but the
# rigid board moves as one.)
CLR_L       = 1.0       # left (-X) gap: just board assembly clearance. The microSD
                        # card's ~2 mm protrusion lives in the wall slot, and the
                        # front/back-left posts float, so nothing else needs room here
CLR_F       = 3.5       # front (-Y, USB-C edge) gap -> Ethernet-limited
IO_CLR      = 0.0       # right (+X, I/O short face) gap. Board edge sits at the
                        # inner wall plane (it rides in the open I/O window), so the
                        # ~3 mm connector overhang ends flush with the 3 mm wall face
BAY_GAP     = 4.0       # gap between Pi and the GPS/IMU bay
BACK_CLR    = 6.0       # behind GPS, for the two rear posts

# --- M2.5 brass heat-set inserts -------------------------------------------
# Physical size of YOUR inserts (datasheet / calipers). These are the INPUTS;
# the pilot hole the model drills is derived from them below.
INSERT_OD   = 3.47      # insert outside diameter (knurled body), mm
INSERT_LEN  = 3.98      # insert length = how deep it sits when pressed flush, mm
#
# A heat-set insert is melted into a hole that is INTENTIONALLY SMALLER than
# the insert's OD. As it's pressed in hot, the plastic softens, the knurls
# bite, and the displaced plastic locks it in place. So:
#   hole too big   -> insert spins / pulls straight back out
#   hole too small -> won't seat flush, may bulge or crack the boss
# The right size is OD minus a small "melt allowance". ~0.25-0.35 mm is a good
# starting point for PETG; this insert size is commonly spec'd at a 3.2 mm
# hole, which the 0.30 below matches (3.47 - 0.30 = 3.17). Confirm on a test
# coupon and trust your insert's datasheet over this default.
MELT_ALLOWANCE   = 0.30  # how much smaller than OD the pilot hole is
HOLE_DEPTH_EXTRA = 0.50  # drill the hole this much deeper than the insert, so
                         # it seats flush and displaced plastic has relief room

INS_HOLE_D  = INSERT_OD  - MELT_ALLOWANCE    # pilot-hole DIAMETER bosses get drilled to
INS_DEPTH   = INSERT_LEN + HOLE_DEPTH_EXTRA  # pilot-hole DEPTH

# Screw-tip RELIEF: a narrower bore continuing below the insert so a screw longer
# than the insert doesn't bottom out on solid plastic. Applied to every insert
# post (board standoffs + lid posts). Set SCREW_RELIEF_EXTRA = 0 to disable.
SCREW_RELIEF_D     = 2.9   # relief bore diameter (M2.5 screw clearance; < INS_HOLE_D)
SCREW_RELIEF_EXTRA = 4.0   # how far the relief reaches PAST the insert
SCREW_RELIEF_FLOOR = 1.0   # min plastic left at the far end (keeps the bottom sealed)

# BOSS_D = outside diameter of the printed pillar that an insert goes into. It
# must leave enough plastic around the insert that it doesn't split on install
# or when the screw is torqued. Rule of thumb for a free-standing boss:
# boss OD >= ~2x insert OD (~6.9 mm here). 6.0 mm leaves a ~1.3 mm wall all
# round -- lean, but fine in this design because nearly every boss is fused
# into the 3 mm case walls/corners, which carry the load. Raise it if any
# free-standing boss cracks; note that growing it may shrink nearby clearances.
BOSS_D      = 6.0
POST_OFF    = 1.0       # lid-post centre, in from the corner (tucked so the front
                        # posts mostly bury into the corner walls -> Pi sits closer)
POST_LEN    = 13.0      # lid posts hang from the top this far (don't reach the
                        # floor); fused to the corner walls + 45 deg taper beneath

# Raspberry Pi 5
PI_L, PI_W  = 85.0, 56.0
PI_HOLE_INSET, PI_HOLE_DX, PI_HOLE_DY = 3.5, 58.0, 49.0
STANDOFF_H  = 6.0       # >= INS_DEPTH-ish; clears microSD holder + cooler nubs
PI_PCB_T    = 1.6
USBC_X      = 11.2
COOLER_L, COOLER_W, COOLER_H = 63.5, 42.5, 14.0

# I/O (+X short) edge connector layout, from the RPi5 mechanical drawing,
# measured along the 56 mm edge from the front (USB-C/HDMI) corner:
#   Ethernet   center ~10.2, ~18.4 wide  -> ~1.0 .. 19.4   (widest, nearest front)
#   USB 3.0    center ~29.1, ~13.3 wide  -> ~22.4 .. 35.8
#   USB 2.0    center ~47.0, ~13.3 wide  -> ~40.3 .. 53.7
# Cluster runs ~1 .. 54 mm. The Ethernet reaches almost to the front corner, so
# the window must start there; a centred window clips the USB-C side first.
IO_WIN_FRONT_INSET = 2.0   # 2 mm in from the front (Ethernet) corner -> trims the
                           # over-wide Ethernet end; back stays put -> 53 wide
IO_WIN_BACK_INSET  = 1.0   # ... ends 1 mm shy of the back (USB2) corner
IO_WIN_H           = 18.0  # height; covers the ~16 mm connector stack

# microSD L-access (card protrudes only ~2 mm)
SD_W           = 16.0    # access width (front-to-back, Y); SAME for side slot + floor notch
SD_CARD_GAP    = 1.0     # side-slot top-to-bottom is 2 mm shorter than before
SD_FLOOR_DEPTH = 7.5     # floor-notch reach INTO the case (was 13.5; -6 mm depth)

# SparkFun NEO-M9N SMA (1.60 x 1.45 in); 4 corner holes 0.10" in.
# The SMA antenna jack is on the board's +X edge and points toward the IMU.
# A 90-deg adapter screws onto it; jack + adapter together reach this far in +X:
GPS_L, GPS_W    = 40.64, 36.83
GPS_HOLE_INSET  = 2.54
GPS_PED_H       = 6.0    # GPS sits low: just tall enough to hold the inserts
SMA_ADAPTER_EXT = 18.0   # jack + right-angle adapter reach, +X off the GPS edge

# ICM-45686 IMU breakout. Two screw bosses (with inserts) on the forward edge,
# two plain support nubs toward the far (wire) edge. The nubs are pulled in
# toward the bosses to clear solder joints on the board underside.
IMU_L, IMU_W   = 20.6, 17.8
IMU_HOLE_SHORT_INSET, IMU_HOLE_LONG_INSET = 2.5, 5.0
IMU_NUB_FAR_INSET = 5.0  # nub set-in from the far edge (was 3.0 -> moved 2 mm in)
IMU_PED_H      = 12.0    # IMU pedestal / nub height (raised +6 mm: opens up ~12 mm
                         # of clearance under the board for cable routing/clips)

# SMA panel-mount bulkhead on the RIGHT (+X) wall, in line with the GPS jack.
# Lowered to sit near the floor so the coiled 6" extender can be tucked down low,
# under/beside the IMU rather than resting against it. SMA_Y/SMA_Z derived below.
SMA_D          = 6.5

# vents
INTAKE_R, INTAKE_HOLE_D, INTAKE_PITCH = 21.0, 4.0, 6.5
SLOT_W, SLOT_COUNT = 3.0, 5

# ----------------------------------------------------------------------------- DERIVED
INT_X = CLR_L + PI_L + IO_CLR
INT_Y = CLR_F + PI_W + BAY_GAP + GPS_W + BACK_CLR
OX, OY, OZ = 2*WALL + INT_X, 2*WALL + INT_Y, WALL + WALL_H

def io(x, y): return (WALL + x, WALL + y)

PIx0, PIy0 = io(CLR_L, CLR_F)
pi_holes = [(PIx0 + PI_HOLE_INSET + dx, PIy0 + PI_HOLE_INSET + dy)
            for dx in (0, PI_HOLE_DX) for dy in (0, PI_HOLE_DY)]
cooler_cx, cooler_cy = PIx0 + PI_L/2, PIy0 + PI_W/2

lid_posts = [io(POST_OFF, POST_OFF), io(INT_X-POST_OFF, POST_OFF),
             io(POST_OFF, INT_Y-POST_OFF), io(INT_X-POST_OFF, INT_Y-POST_OFF)]

# guards for the floated front lid posts:
POST_BOTTOM_Z = OZ - POST_LEN - BOSS_D/2          # tip of the 45-deg taper
assert WALL + STANDOFF_H + PI_PCB_T < POST_BOTTOM_Z, \
    "Pi PCB does not clear under the floating lid posts"
# front-right post vs the tall I/O connector nearest the front corner:
IO_FRONT_CONN_S = 1.0                              # near edge of that connector
FR_CONN_GAP = (PIy0 + IO_FRONT_CONN_S) - io(0, POST_OFF)[1] - BOSS_D/2
assert FR_CONN_GAP >= 0, f"front-right post fouls the I/O connector by {-FR_CONN_GAP:.2f} mm"

GPSx0, GPSy0 = io(3, CLR_F + PI_W + BAY_GAP)
gps_holes = [(GPSx0 + hx, GPSy0 + hy)
             for hx in (GPS_HOLE_INSET, GPS_L - GPS_HOLE_INSET)
             for hy in (GPS_HOLE_INSET, GPS_W - GPS_HOLE_INSET)]

# IMU centred laterally between the GPS right edge and the right (bulkhead) wall.
# With the straight SMA adapter the cable runs BEHIND the IMU, so the old wide
# GPS->IMU "adapter gap" is no longer needed -- centring also pulls the IMU off
# the right wall, giving the bulkhead and the cable loop more room on that side.
IMUy0 = io(0, CLR_F + PI_W + BAY_GAP + 2)[1]
IMUx0 = ((GPSx0 + GPS_L) + (OX - WALL)) / 2 - IMU_L / 2
imu_holes = [(IMUx0 + IMU_HOLE_SHORT_INSET,        IMUy0 + IMU_HOLE_LONG_INSET),
             (IMUx0 + IMU_L - IMU_HOLE_SHORT_INSET, IMUy0 + IMU_HOLE_LONG_INSET)]
imu_nubs  = [(IMUx0 + 3,         IMUy0 + IMU_W - IMU_NUB_FAR_INSET),
             (IMUx0 + IMU_L - 3, IMUy0 + IMU_W - IMU_NUB_FAR_INSET)]

# GPS->IMU gap is now just a routing/clearance gap (cable runs behind the IMU,
# not through here). Keep the IMU off the GPS and inside the right wall.
SMA_GAP = IMUx0 - (GPSx0 + GPS_L)        # GPS right edge -> IMU left edge
assert SMA_GAP >= 4.0, f"GPS-IMU gap {SMA_GAP:.1f} too small"
assert IMUx0 + IMU_L <= OX - WALL - 1.0, "IMU overruns the right wall (bay too wide for the box)"

# SMA bulkhead: RIGHT (+X) wall, IN LINE with the GPS jack (which points +X).
# Lowered toward the floor (was at jack height ~13) so the cable exit is low and
# the two ends of the loop -- jack vs bulkhead -- don't fight each other. The
# hole bottom is kept >=1.5 mm above the floor for wall material.
SMA_Y = GPSy0 + GPS_W - 11.18              # jack sits 11.18 mm from the GPS back edge
SMA_Z = WALL + 5.0                         # ~5 mm above the floor (hole spans ~4.75..11.25)
assert SMA_Z - SMA_D/2 >= WALL + 1.4, "SMA hole too low: <1.4 mm wall below it"
assert SMA_Y - WALL > (IMUy0 - WALL) + IMU_W + 3, "SMA bulkhead not clear behind the IMU"

# cable hold-down clips. Two run ALONG X behind the IMU (the jack->port leg);
# a third runs ALONG Y in the GPS-IMU gap to catch the cable where the big loop
# comes back around the IMU. Each entry: (x, y, cable-axis). Easy to nudge.
# INSTALL_CLIPS gates whether they're baked into the base (off during trials).
INSTALL_CLIPS = False
cable_clips = [(GPSx0 + GPS_L + 11.0, SMA_Y,                'x'),
               (IMUx0 + IMU_L*0.55,   SMA_Y,                'x'),
               ((GPSx0 + GPS_L + IMUx0)/2, IMUy0 + IMU_W*0.45, 'y')]
assert SMA_Y - 3.5 > IMUy0 + IMU_W, "X cable clips would touch the IMU back edge"
_gx = (GPSx0 + GPS_L + IMUx0)/2
assert GPSx0 + GPS_L < _gx - 2.8 and _gx + 2.8 < IMUx0, "gap (Y) clip overruns GPS/IMU"

# ----------------------------------------------------------------------------- BASE
def boss(points, top_z, with_insert=True, d=BOSS_D):
    s = cq.Workplane("XY").pushPoints(points).circle(d/2).extrude(top_z)
    if with_insert:
        s = s.faces(">Z").workplane().pushPoints(points).hole(INS_HOLE_D, INS_DEPTH)
        relief = min(INS_DEPTH + SCREW_RELIEF_EXTRA, top_z - SCREW_RELIEF_FLOOR)
        if relief > INS_DEPTH:
            s = s.faces(">Z").workplane().pushPoints(points).hole(SCREW_RELIEF_D, relief)
    return s

def lid_boss(points, post_len, d=BOSS_D):
    # Lid-screw posts that hang from the top instead of reaching the floor, so
    # the board can pass beneath them. Each is a cylinder fused into the corner
    # walls, with a 45-deg cone underneath so the overhang prints support-free.
    z_cyl = OZ - post_len
    z_tip = z_cyl - d/2
    s = None
    for (px, py) in points:
        col = (cq.Workplane("XY").workplane(offset=z_tip)
               .circle(0.4).workplane(offset=d/2).circle(d/2).loft()      # 45-deg taper
               .faces(">Z").workplane().circle(d/2).extrude(post_len)     # cylinder to OZ
               .translate((px, py, 0)))
        s = col if s is None else s.union(col)
    s = s.faces(">Z").workplane().pushPoints(points).hole(INS_HOLE_D, INS_DEPTH)
    relief = min(INS_DEPTH + SCREW_RELIEF_EXTRA, post_len - SCREW_RELIEF_FLOOR)
    if relief > INS_DEPTH:
        s = s.faces(">Z").workplane().pushPoints(points).hole(SCREW_RELIEF_D, relief)
    return s

def cable_clip(cx, cy, axis='x', slot_w=2.60, wall_t=1.5, h=3.4, length=5.0,
               nib=0.26, roof_t=0.9):
    # Snug snap clip sized for a 2.48 mm coax. The pocket is cable-width (slot_w),
    # and the retaining roof sits right at the TOP of the cable (roof underside =
    # h - roof_t ~= 2.5 mm above the floor) so the cable is pinned against the
    # floor with almost no vertical play -- this is the key fix vs the old loose
    # clip whose nibs sat ~5 mm up. The slit between the roof ledges
    # (slot_w - 2*nib ~= 2.08) is narrower than the cable, so it snaps in and stays.
    # Open along `axis` so connectors never thread through.
    roof_z = h - roof_t                       # roof underside height above floor
    g = None
    for s in (-1, 1):
        off  = s * (slot_w/2 + wall_t/2)
        noff = s * (slot_w/2 - nib/2)
        if axis == 'x':                       # walls run in X, slot across Y
            w  = (cq.Workplane("XY").box(length, wall_t, h, centered=(True,True,False))
                  .translate((cx, cy + off, WALL)))
            nb = (cq.Workplane("XY").box(length, nib, roof_t, centered=(True,True,False))
                  .translate((cx, cy + noff, WALL + roof_z)))
        else:                                 # walls run in Y, slot across X
            w  = (cq.Workplane("XY").box(wall_t, length, h, centered=(True,True,False))
                  .translate((cx + off, cy, WALL)))
            nb = (cq.Workplane("XY").box(nib, length, roof_t, centered=(True,True,False))
                  .translate((cx + noff, cy, WALL + roof_z)))
        w = w.union(nb)
        g = w if g is None else g.union(w)
    try:                                      # flare the slit top as a lead-in
        g = g.faces(">Z").chamfer(0.25)
    except Exception:
        pass
    return g

def build_base():
    b = cq.Workplane("XY").box(OX, OY, OZ, centered=False).faces(">Z").shell(-WALL)
    b = b.union(boss(pi_holes,  WALL + STANDOFF_H))
    b = b.union(lid_boss(lid_posts, POST_LEN))
    b = b.union(boss(gps_holes, WALL + GPS_PED_H))
    b = b.union(boss(imu_holes, WALL + IMU_PED_H))
    b = b.union(boss(imu_nubs,  WALL + IMU_PED_H, with_insert=False, d=4.0))

    # cable hold-downs. OFF for now (INSTALL_CLIPS=False): positions are being
    # found empirically with glue-down test clips, since the stiff ~1.5" sections
    # at each connector mean the cable only bends in the middle. Once the working
    # spots are known, set the coords in cable_clips and flip INSTALL_CLIPS=True.
    if INSTALL_CLIPS:
        for (cx, cy, ax) in cable_clips:
            b = b.union(cable_clip(cx, cy, ax))

    # USB-C cutout (front wall)
    b = b.cut(cq.Workplane("XY").box(13, WALL*3, 9, centered=(True,True,False))
              .translate((PIx0 + USBC_X, WALL, WALL + STANDOFF_H - 0.5)))

    # microSD L-access: side slot (lower -X wall) + floor notch under the card
    sd_y = PIy0 + PI_W/2
    b = b.cut(cq.Workplane("XY").box(8, SD_W, WALL+STANDOFF_H+SD_CARD_GAP, centered=(True,True,False))
              .translate((WALL, sd_y, 0)))
    b = b.cut(cq.Workplane("XY").box(SD_FLOOR_DEPTH, SD_W, WALL*3, centered=(False,True,True))
              .translate((-1, sd_y, WALL)))

    # I/O window (right wall): Ethernet + USB-A x4. Width/position set from the
    # connector layout above so all three clear and can insert toward flush.
    io_w  = PI_W - IO_WIN_FRONT_INSET - IO_WIN_BACK_INSET
    io_cy = PIy0 + IO_WIN_FRONT_INSET + io_w/2
    b = b.cut(cq.Workplane("XY").box(WALL*3, io_w, IO_WIN_H, centered=(True,True,False))
              .translate((OX-WALL, io_cy, WALL + STANDOFF_H)))

    # SMA bulkhead (RIGHT wall, in line with the GPS jack -> straight cable run)
    b = b.cut(cq.Workplane("YZ").workplane(offset=OX-WALL*1.5).center(SMA_Y, SMA_Z)
              .circle(SMA_D/2).extrude(WALL*3))

    # exhaust slots (left wall)
    slot = cq.Workplane("XY").box(WALL*3, SLOT_W, WALL_H-12, centered=(True,True,False))
    for i in range(SLOT_COUNT):
        y = PIy0 + (i+0.5)*(PI_W/SLOT_COUNT)
        b = b.cut(slot.translate((0, y, WALL+5)))
    return b

# ----------------------------------------------------------------------------- LID
def lipbar(x0, y0, dx, dy):
    return cq.Workplane("XY").box(dx, dy, LID_LIP_H, centered=False)\
             .translate((x0, y0, OZ - LID_LIP_H))

def build_lid():
    lid = cq.Workplane("XY").box(OX, OY, LID_T, centered=False).translate((0,0,OZ))

    # segmented alignment lip on all four sides, with corner breaks for the posts.
    # The right (I/O) lip sits at z>=OZ-LID_LIP_H, ~1.7 mm above the tallest USB
    # stack, registering on the wall strip above the I/O window.
    g, t = LID_LIP_GAP, LIP_T
    span_x = (WALL+LIP_CORNER_GAP, INT_X-2*LIP_CORNER_GAP)
    span_y = (WALL+LIP_CORNER_GAP, INT_Y-2*LIP_CORNER_GAP)
    lid = lid.union(lipbar(span_x[0], WALL+g,            span_x[1], t))            # front
    lid = lid.union(lipbar(span_x[0], WALL+INT_Y-g-t,    span_x[1], t))            # back
    lid = lid.union(lipbar(WALL+g,    span_y[0],         t,         span_y[1]))    # left
    lid = lid.union(lipbar(WALL+INT_X-g-t, span_y[0],    t,         span_y[1]))    # right (I/O)

    # intake grille over the cooler
    pts, n = [], int(INTAKE_R/INTAKE_PITCH)+1
    for i in range(-n, n+1):
        for j in range(-n, n+1):
            px, py = i*INTAKE_PITCH, j*INTAKE_PITCH
            if px*px+py*py <= (INTAKE_R-INTAKE_HOLE_D/2)**2:
                pts.append((cooler_cx+px, cooler_cy+py))
    lid = lid.cut(cq.Workplane("XY").pushPoints(pts).circle(INTAKE_HOLE_D/2)
                  .extrude(LID_T+1).translate((0,0,OZ-0.5)))

    # lid screw holes: Ø2.8 clearance through, + counterbore for the socket cap
    # head (depth = head + 0.3 so it seats just below the surface; ~1.4 mm of
    # solid lid remains beneath it at LID_T=4)
    cb_depth = SCREW_HEAD_H + 0.3
    cb_r     = (SCREW_HEAD_D + 0.5) / 2
    lid = lid.cut(cq.Workplane("XY").pushPoints(lid_posts).circle(1.4)
                  .extrude(LID_T+1).translate((0,0,OZ-0.5)))
    lid = lid.cut(cq.Workplane("XY").pushPoints(lid_posts).circle(cb_r)
                  .extrude(cb_depth+0.1).translate((0,0,OZ+LID_T-cb_depth)))

    # rear exhaust slots over the bay
    for i in range(5):
        lid = lid.cut(cq.Workplane("XY").box(3, 22, LID_T+1, centered=True)
                      .translate((OX/2 + (i-2)*9, GPSy0+GPS_W/2, OZ+LID_T/2)))
    return lid

# ----------------------------------------------------------------------------- BUILD + EXPORT
if __name__ == "__main__":
    base = build_base()
    lid  = build_lid()

    # lid for printing: flip 180 deg about X so the flat top is on the bed (no lip support)
    lid_print = lid.rotate((0,0,0),(1,0,0),180)
    bb = lid_print.val().BoundingBox()
    lid_print = lid_print.translate((-bb.xmin, -bb.ymin, -bb.zmin))

    cq.exporters.export(base, "case_base.step")
    cq.exporters.export(base, "case_base.stl", tolerance=0.05)
    cq.exporters.export(lid_print, "case_lid.step")
    cq.exporters.export(lid_print, "case_lid.stl", tolerance=0.05)
    cq.exporters.export(lid, "_lid_asm.stl", tolerance=0.05)   # assembled, for rendering only

    asm = cq.Assembly()
    asm.add(base, name="base", color=cq.Color(0.30,0.45,0.65))
    asm.add(lid,  name="lid",  color=cq.Color(0.75,0.78,0.82))
    asm.save("case_assembly.step")

    print(f"Outer footprint : {OX:.1f} x {OY:.1f} x {OZ+LID_T:.1f} mm")
    print("Exported base/lid .step/.stl (+ assembly). Lid STL is print-oriented (flipped).")
